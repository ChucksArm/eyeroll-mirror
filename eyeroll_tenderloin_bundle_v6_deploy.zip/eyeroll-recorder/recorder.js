import { connect } from 'nats.ws';
import fs from 'node:fs';
import path from 'node:path';

const AREA = 'sfc.tenderloin';
const OUT = path.resolve('frames');
const CAMERAS = {
  '5ee1f43a8a': 'Hyde St. North',
  'c90d3277cb': 'Hyde St. South',
  '40a42695f7': 'Hyde St. West 1',
  '4afbc73537': 'Hyde & Ellis SW',
  'f13218e5fb': 'Hyde St. West 2',
  '37b4395efd': 'Ellis St. East',
  '13e7de7d24': 'Ellis St. West',
  '7eca7562cd': 'Ellis St. West Detail'
};

function ts(d = new Date()) {
  return d.toISOString().replace(/[:.]/g, '-');
}

function ensure(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

async function main() {
  ensure(OUT);
  const nc = await connect({
    servers: 'wss://websock.eyeroll.live',
    user: 'website',
    pass: 'Wp6MLpqooWunoE8qgakedMJPqonXRT',
    maxReconnectAttempts: -1,
    pingInterval: 40000,
    waitOnFirstConnect: true
  });

  console.log('Connected to', nc.getServer());
  const sub = nc.subscribe(`feed.${AREA}.*.image`);

  for await (const msg of sub) {
    const parts = msg.subject.split('.');
    const cameraId = parts[2];
    const now = new Date();
    const day = now.toISOString().slice(0, 10);

    // Schema: frames/<camera-id>/<YYYY-MM-DD>/<camera-id>_<timestamp>.jpg
    const dir = path.join(OUT, cameraId, day);
    ensure(dir);

    const stamp = ts(now);
    const filename = `${cameraId}_${stamp}.jpg`;
    const file = path.join(dir, filename);

    fs.writeFileSync(file, Buffer.from(msg.data));
    console.log(`${now.toISOString()} ${cameraId} ${CAMERAS[cameraId] || 'Unknown'} -> ${file}`);
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
