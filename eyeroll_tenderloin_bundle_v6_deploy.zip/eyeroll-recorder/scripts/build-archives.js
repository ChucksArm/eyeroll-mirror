import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const FRAMES = path.resolve('frames');
const ARCHIVE = path.resolve('archive');
const CYCLE_MS = 6 * 60 * 60 * 1000;
const CAMERAS = {
  '5ee1f43a8a': 'Hyde St. North',
  'c90d3277cb': 'Hyde St. South',
  '40a42695f7': 'Hyde St. West 1',
  '4afbc73537': 'Hyde & Ellis SW',
  'f13218e5fb': 'Hyde St. West 2',
  '37b4395efd': 'Ellis St. East',
  '13e7de7d24': 'Ellis St. West',
  '7eca7562cd': 'Ellis St. West Detail'
};

fs.mkdirSync(ARCHIVE, { recursive: true });

function allJpgs(camDir) {
  const out = [];
  for (const day of fs.readdirSync(camDir)) {
    const dayDir = path.join(camDir, day);
    if (!fs.statSync(dayDir).isDirectory()) continue;
    for (const file of fs.readdirSync(dayDir)) {
      if (file.endsWith('.jpg')) out.push(path.join(dayDir, file));
    }
  }
  return out.sort();
}

function parseTs(file, cameraId) {
  const base = path.basename(file, '.jpg').replace(`${cameraId}_`, '');
  const m = base.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2})-(\d{2})-(\d{2})-(\d+)/);
  if (!m) return null;
  return new Date(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}.${m[7]}Z`);
}

for (const cameraId of fs.existsSync(FRAMES) ? fs.readdirSync(FRAMES) : []) {
  const camDir = path.join(FRAMES, cameraId);
  if (!fs.statSync(camDir).isDirectory()) continue;
  const files = allJpgs(camDir);
  if (!files.length) continue;

  const groups = [];
  let current = [];
  let cycleStart = parseTs(files[0], cameraId)?.getTime() || Date.now();

  for (const file of files) {
    const t = parseTs(file, cameraId)?.getTime();
    if (!t) continue;
    if (t - cycleStart >= CYCLE_MS && current.length) {
      groups.push(current);
      current = [];
      cycleStart = t;
    }
    current.push(file);
  }
  if (current.length) groups.push(current);

  const outDir = path.join(ARCHIVE, cameraId);
  fs.mkdirSync(outDir, { recursive: true });

  groups.forEach((group, idx) => {
    const first = parseTs(group[0], cameraId);
    const stamp = first.toISOString().replace(/[:.]/g, '-');
    const outFile = path.join(outDir, `${cameraId}_${stamp}.mp4`);
    if (fs.existsSync(outFile)) return;

    const manifest = path.join(outDir, `manifest-${idx}.txt`);
    const lines = group.map(f => `file '${path.resolve(f).replace(/'/g, "'\\''")}'\nduration 0.1667`);
    lines.push(`file '${path.resolve(group[group.length - 1]).replace(/'/g, "'\\''")}'`);
    fs.writeFileSync(manifest, lines.join('\n'));

    spawnSync('ffmpeg', [
      '-y', '-f', 'concat', '-safe', '0', '-i', manifest,
      '-vf', 'fps=6', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', outFile
    ], { stdio: 'inherit' });

    fs.unlinkSync(manifest);
    console.log(`Archived ${CAMERAS[cameraId] || cameraId} -> ${outFile}`);
  });
}
