import fs from 'node:fs';
import path from 'node:path';

const ARCHIVE = path.resolve('archive');
const OUT = path.resolve('../eyeroll-mirror/archive-index.json');
const CAMERAS = {
  '5ee1f43a8a': 'Hyde St. North',
  'c90d3277cb': 'Hyde St. South',
  '40a42695f7': 'Hyde St. West 1',
  '4afbc73537': 'Hyde & Ellis SW',
  'f13218e5fb': 'Hyde St. West 2',
  '37b4395efd': 'Ellis St. East',
  '13e7de7d24': 'Ellis St. West',
  '7eca7562cd': 'Ellis St. West Detail'
};

const cycles = [];
if (fs.existsSync(ARCHIVE)) {
  for (const cameraId of fs.readdirSync(ARCHIVE)) {
    const dir = path.join(ARCHIVE, cameraId);
    if (!fs.statSync(dir).isDirectory()) continue;
    for (const file of fs.readdirSync(dir).filter(f => f.endsWith('.mp4')).sort().reverse()) {
      const stamp = file.replace(`${cameraId}_`, '').replace('.mp4', '');
      cycles.push({
        cameraId,
        title: CAMERAS[cameraId] || cameraId,
        start: stamp,
        end: '6 hours later',
        url: `../eyeroll-recorder/archive/${cameraId}/${file}`
      });
    }
  }
}
fs.writeFileSync(OUT, JSON.stringify({ cycles }, null, 2));
console.log(`Wrote ${OUT}`);
