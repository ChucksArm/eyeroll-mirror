#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm run latest
npm run archive
npm run index
