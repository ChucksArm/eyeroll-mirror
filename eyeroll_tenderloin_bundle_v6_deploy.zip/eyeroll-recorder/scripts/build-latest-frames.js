import fs from 'node:fs';
import path from 'node:path';

const FRAMES = path.resolve('frames');
const OUT = path.resolve('../eyeroll-mirror/latest-frames.json');
const frames = {};

function newestFile(camDir) {
  let latest = null;
  if (!fs.existsSync(camDir)) return null;
  for (const day of fs.readdirSync(camDir)) {
    const dayDir = path.join(camDir, day);
    if (!fs.statSync(dayDir).isDirectory()) continue;
    for (const file of fs.readdirSync(dayDir)) {
      if (!file.endsWith('.jpg')) continue;
      const full = path.join(dayDir, file);
      if (!latest || full > latest) latest = full;
    }
  }
  return latest;
}

if (fs.existsSync(FRAMES)) {
  for (const cameraId of fs.readdirSync(FRAMES)) {
    const camDir = path.join(FRAMES, cameraId);
    if (!fs.statSync(camDir).isDirectory()) continue;
    const latest = newestFile(camDir);
    if (!latest) continue;
    const rel = path.relative(path.resolve('.'), latest).replace(/\\/g, '/');
    frames[cameraId] = {
      url: `../eyeroll-recorder/${rel}`,
      timestamp: path.basename(latest, '.jpg').replace(`${cameraId}_`, '')
    };
  }
}

fs.writeFileSync(OUT, JSON.stringify({ frames }, null, 2));
console.log(`Wrote ${OUT}`);
