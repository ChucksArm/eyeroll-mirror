# Eyeroll Tenderloin mirror + recorder (v2 schema)

This project archives the Tenderloin camera feed and displays a delayed mirror
of the archived images instead of connecting the browser directly to the live
WebSocket feed.

## New schema

Frames are saved as:

```text
frames/<camera-id>/<YYYY-MM-DD>/<camera-id>_<timestamp>.jpg
```

Archives are saved as:

```text
archive/<camera-id>/<camera-id>_<cycle-start-timestamp>.mp4
```

Because every filename is prefixed with the camera ID, and every folder is
split by camera and by day, frames from different feeds are never mixed
together and always sort correctly by time.

## Cameras

| Camera ID    | Title                  |
|--------------|-------------------------|
| 5ee1f43a8a   | Hyde St. North          |
| c90d3277cb   | Hyde St. South          |
| 40a42695f7   | Hyde St. West 1         |
| 4afbc73537   | Hyde & Ellis SW         |
| f13218e5fb   | Hyde St. West 2         |
| 37b4395efd   | Ellis St. East          |
| 13e7de7d24   | Ellis St. West          |
| 7eca7562cd   | Ellis St. West Detail   |

## Install (Intel MacBook Pro)

```bash
cd output/eyeroll-recorder
chmod +x setup-macbook-intel.sh
./setup-macbook-intel.sh
```

That checks for Node and ffmpeg, runs `npm install`, and makes the helper
scripts executable.

## Record live frames

```bash
npm start
```

This connects to the live feed and writes JPEGs using the schema above.
Leave this running in its own terminal tab.

## Refresh archive + indexes

In a second terminal tab, from the same `eyeroll-recorder` folder:

```bash
./scripts/refresh-all.sh
```

This runs, in order:

```bash
npm run latest    # writes ../eyeroll-mirror/latest-frames.json
npm run archive   # builds 6-hour MP4s in archive/<camera-id>/
npm run index     # writes ../eyeroll-mirror/archive-index.json
```

Run this on a schedule (cron, launchd, or manually) to keep the mirror page
up to date. Every run picks up new frames since the last archive cycle.

## Serve the mirror locally

From the parent `output` folder (not from inside `eyeroll-recorder` or
`eyeroll-mirror`):

```bash
cd output
python -m http.server 8000
```

Then open:

```text
http://localhost:8000/eyeroll-mirror/tenderloin-mirror-static.html
```

## Mirror page behavior

- Auto-refreshes every 5 seconds, re-fetching `latest-frames.json` and
  `archive-index.json`.
- Includes a manual "Refresh now" button for instant updates outside the
  5-second cycle.
- Never opens a WebSocket connection in the browser, so it works even under
  strict Content-Security-Policy settings that block `unsafe-eval`.
- Cache-busts each image request with a timestamp query string so the
  browser doesn't show a stale cached JPEG.

## Why the delayed-archive approach

Instead of connecting the mirror page directly to
`wss://websock.eyeroll.live`, the recorder stays connected to the live feed
and continuously writes frames to disk. The mirror page only ever reads
already-saved files from the local archive, which:

- Avoids browser CSP/eval restrictions entirely.
- Naturally introduces a short delay (the time between recorder writes and
  the next `refresh-all.sh` run).
- Makes debugging easy, since every frame is a plain JPEG file on disk.

## Troubleshooting

- If cards show "Not available yet," the recorder hasn't written a frame for
  that camera, or you haven't run `npm run latest` since it did.
- If archives are empty, confirm `ffmpeg` is installed (`ffmpeg -version`).
- Always serve from the parent `output` folder so relative paths between
  `eyeroll-mirror` and `eyeroll-recorder` resolve correctly.
