#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required. Install it first (brew install node) and rerun." >&2
  exit 1
fi

if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg is required. Install it first (brew install ffmpeg) and rerun." >&2
  exit 1
fi

npm install
chmod +x scripts/refresh-all.sh

echo "Setup complete."
echo "Next steps:"
echo "  1) node recorder.js                 # start recording live frames"
echo "  2) ./scripts/refresh-all.sh          # build latest-frames + archives + index"
echo "  3) cd .. && python -m http.server 8000"
echo "  4) open http://localhost:8000/eyeroll-mirror/tenderloin-mirror-static.html"
